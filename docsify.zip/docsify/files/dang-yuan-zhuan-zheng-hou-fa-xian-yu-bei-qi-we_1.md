[首页](https://www.ccdi.gov.cn/)  > 互动交流 > 业务探讨

## 党员转正后发现预备期违纪如何处理？

### 

_来源：中央纪委监察部网站_ _发布时间： 2017-02-16 08:30_

　　网友“李杜之风”：党员预备期违纪，转正后被发现，该如何处理？

___

　　中央纪委法规室：根据党章第七条规定，预备党员的义务同正式党员一样，必须遵守党的各项纪律。党员转正后发现预备期违纪，党组织可以给以批评教育直至纪律处分。

![](https://www.ccdi.gov.cn/hdjln/ywtt/201702/W020210531593368233019.jpg) 

[![](https://www.ccdi.gov.cn/hdjln/ywtt/201702/W020210531593368324436.jpg)](http://www.ccdi.gov.cn/hdjl/hfxd/index.html)      [![](https://www.ccdi.gov.cn/hdjln/ywtt/201702/W020210531593368428717.jpg)](http://interact.ccdi.gov.cn/lyb/index.html) 

[\>>点击查看更多回复](http://www.ccdi.gov.cn/hdjl/hfxd/index.html)　　　　　　　　　　　　　　　[\>>点击进入留言咨询](http://interact.ccdi.gov.cn/lyb/index.html)